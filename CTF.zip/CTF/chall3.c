#include <stdio.h>
#include <string.h>

int main() {
    char input[50];
    int key[] = {11, 4, 7, 1, 2};
    int flag[] = {109, 99, 111, 108, 112};
    
    printf("Enter key: ");
    scanf("%s", input);
    
    int ok = 1;
    for (int i = 0; i < 5; i++) {
        if (((input[i] ^ key[i]) + 5) != flag[i]) {
            ok = 0;
            break;
        }
    }
    
    if (ok)
        printf("flag{bitwise_fun}\n");
    else
        printf("Wrong!\n");
}

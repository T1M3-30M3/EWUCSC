#include <stdio.h>

int main() {
    unsigned char bytes[] = {0x66, 0x6c, 0x61, 0x67, 0x7b, 0x68, 0x65, 0x78, 0x5f, 0x66, 0x75, 0x6e, 0x7d, 0x00};
    printf("Find a way to print the flag hidden in this program.\n");
    // Hint: It's already in memory ;)
    return 0;
}
